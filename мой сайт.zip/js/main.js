const songs = [
    {
        title: "Водочки принеси",
        artist: "Тяжелая Атлетика",
        description: "Искренность русской души в каждом аккорде",
        audio: "assets/audio/mus.mp3"
    },
    {
        title: "Чёрный Гранит",
        artist: "1 kla$",
        description: "Твердость характера и сила духа",
        audio: "assets/audio/mus1.mp3"
    },
    {
        title: "Я устал",
        artist: "1 kla$",
        description: "Откровение о выгорании и поиске сил",
        audio: "assets/audio/mus2.mp3"
    },
    {
        title: "Dark.Net",
        artist: "WhiteG",
        description: "Погружение в глубины цифрового подполья",
        audio: "assets/audio/mus3.mp3"
    },
    {
        title: "Street Mode",
        artist: "n8p2un",
        description: "Ритмы городских улиц и ночных гонок",
        audio: "assets/audio/mus4.mp3"
    }
];

function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 768;
}

function initAudioControl() {
    const audio = document.getElementById('bg-music');
    const playPromise = audio.play();
    
    if (playPromise !== undefined) {
        playPromise.then(() => {
        }).catch(error => {
        });
    }
}

window.onload = function() {
    if (!isMobileDevice() && window.innerWidth > 768) {
        return;
    }
    
    initIntroAnimation();
    initAudioControl();
    initScrollAnimations();
    initMusicSlider();
    initNotesAnimation();
    
    setInterval(drawMatrix, 50);
};
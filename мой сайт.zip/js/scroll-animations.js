function initScrollAnimations() {
    const quoteElement = document.getElementById('cyber-quote');
    
    function checkVisibility() {
        const rect = quoteElement.getBoundingClientRect();
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;
        
        if (rect.top <= windowHeight * 0.75 && rect.bottom >= 0) {
            quoteElement.classList.add('visible');
        } else {
            quoteElement.classList.remove('visible');
        }
    }
    
    window.addEventListener('load', checkVisibility);
    window.addEventListener('scroll', checkVisibility);
}

function initNotesAnimation() {
    const notesContainer = document.getElementById('notes-container');
    const noteSymbols = ['♩', '♪', '♫', '♬', '♭', '♮', '♯'];
    
    function createNote() {
        const note = document.createElement('div');
        note.className = 'note';
        note.textContent = noteSymbols[Math.floor(Math.random() * noteSymbols.length)];
        
        const left = Math.random() * 100;
        note.style.left = `${left}%`;
        
        const delay = Math.random() * 5;
        note.style.animationDelay = `${delay}s`;
        
        const duration = 5 + Math.random() * 10;
        note.style.animation = `floatNote ${duration}s linear infinite`;
        
        const size = 0.8 + Math.random() * 1.2;
        note.style.fontSize = `${size}rem`;
        
        const opacity = 0.3 + Math.random() * 0.5;
        note.style.opacity = opacity;
        
        notesContainer.appendChild(note);
        
        setTimeout(() => {
            if (note.parentNode === notesContainer) {
                notesContainer.removeChild(note);
            }
        }, duration * 1000);
    }
    
    setInterval(createNote, 300);
    
    for (let i = 0; i < 10; i++) {
        setTimeout(createNote, i * 300);
    }
}
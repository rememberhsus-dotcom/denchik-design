function initIntroAnimation() {
    const resolveText = document.getElementById('resolve-text');
    const letters = ['Т', 'А', 'Н', 'O', 'С'];
    const allChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*';
    
    canvas.style.opacity = '0.7';
    
    letters.forEach((finalLetter, index) => {
        const letterElement = document.createElement('span');
        letterElement.className = 'letter';
        letterElement.textContent = allChars[Math.floor(Math.random() * allChars.length)];
        letterElement.dataset.final = finalLetter;
        letterElement.style.opacity = '1';
        resolveText.appendChild(letterElement);
    });
    
    const letterElements = document.querySelectorAll('.letter');
    
    let changeCount = 0;
    const maxChanges = 20;
    const changeInterval = setInterval(() => {
        letterElements.forEach(letter => {
            letter.textContent = allChars[Math.floor(Math.random() * allChars.length)];
        });
        
        changeCount++;
        if (changeCount >= maxChanges) {
            clearInterval(changeInterval);
            
            letterElements.forEach((letter, index) => {
                setTimeout(() => {
                    letter.textContent = letter.dataset.final;
                    letter.style.textShadow = '0 0 20px rgba(255, 255, 255, 1)';
                }, index * 100);
            });
            
            setTimeout(() => {
                letterElements.forEach((letter, index) => {
                    setTimeout(() => {
                        const angle = Math.random() * Math.PI * 2;
                        const distance = 300 + Math.random() * 500;
                        const x = Math.cos(angle) * distance;
                        const y = Math.sin(angle) * distance;
                        
                        letter.style.transition = 'all 0.8s ease-out';
                        letter.style.opacity = '0';
                        letter.style.transform = `translate(${x}px, ${y}px) scale(0.1)`;
                    }, index * 80);
                });
                
                setTimeout(() => {
                    document.getElementById('intro').style.opacity = '0';
                    document.getElementById('intro').style.transition = 'opacity 1s ease-in-out';
                    
                    setTimeout(() => {
                        document.getElementById('intro').style.display = 'none';
                        document.getElementById('main-content').style.opacity = '1';
                        canvas.style.opacity = '0.3';
                    }, 1000);
                }, 1000);
            }, 1500);
        }
    }, 100);
}
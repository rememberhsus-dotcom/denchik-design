function initMusicSlider() {
    const sliderContainer = document.getElementById('slider-container');
    const slideIndicators = document.getElementById('slide-indicators');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    
    let currentSlide = 0;
    let currentAudio = null;
    let currentButton = null;
    
    songs.forEach((song, index) => {
        const slide = document.createElement('div');
        slide.className = 'slide';
        slide.innerHTML = `
            <div class="song-cover">
                <i class="fas fa-music"></i>
            </div>
            <div class="song-info">
                <h3 class="song-title">${song.title}</h3>
                <p class="song-artist">${song.artist}</p>
                <p class="song-description">${song.description}</p>
            </div>
            <div class="song-controls">
                <button class="play-btn" data-audio="${song.audio}">
                    <i class="fas fa-play"></i>
                </button>
                <div class="progress-container">
                    <div class="progress-bar"></div>
                </div>
            </div>
        `;
        sliderContainer.appendChild(slide);
        
        const indicator = document.createElement('div');
        indicator.className = 'slide-indicator';
        if (index === 0) indicator.classList.add('active');
        indicator.addEventListener('click', () => {
            goToSlide(index);
        });
        slideIndicators.appendChild(indicator);
    });
    
    function goToSlide(slideIndex) {
        currentSlide = slideIndex;
        sliderContainer.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        document.querySelectorAll('.slide-indicator').forEach((indicator, index) => {
            if (index === currentSlide) {
                indicator.classList.add('active');
            } else {
                indicator.classList.remove('active');
            }
        });
        
        if (currentAudio) {
            currentAudio.pause();
            currentAudio.currentTime = 0;
            if (currentButton) {
                currentButton.classList.remove('playing');
                currentButton.innerHTML = '<i class="fas fa-play"></i>';
            }
            currentAudio = null;
            currentButton = null;
        }
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % songs.length;
        goToSlide(currentSlide);
    }
    
    function prevSlide() {
        currentSlide = (currentSlide - 1 + songs.length) % songs.length;
        goToSlide(currentSlide);
    }
    
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);
    
    const playButtons = document.querySelectorAll('.play-btn');
    const progressBars = document.querySelectorAll('.progress-bar');
    
    playButtons.forEach((button, index) => {
        const audioFile = button.getAttribute('data-audio');
        const audio = new Audio(audioFile);
        const progressBar = progressBars[index];
        
        button.addEventListener('click', () => {
            if (currentAudio === audio) {
                if (audio.paused) {
                    audio.play();
                    button.classList.add('playing');
                    button.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    audio.pause();
                    button.classList.remove('playing');
                    button.innerHTML = '<i class="fas fa-play"></i>';
                }
            } else {
                if (currentAudio) {
                    currentAudio.pause();
                    currentAudio.currentTime = 0;
                    if (currentButton) {
                        currentButton.classList.remove('playing');
                        currentButton.innerHTML = '<i class="fas fa-play"></i>';
                    }
                }
                
                audio.play();
                button.classList.add('playing');
                button.innerHTML = '<i class="fas fa-pause"></i>';
                
                currentAudio = audio;
                currentButton = button;
            }
        });
        
        audio.addEventListener('timeupdate', () => {
            const progress = (audio.currentTime / audio.duration) * 100;
            progressBar.style.width = `${progress}%`;
        });
        
        audio.addEventListener('ended', () => {
            button.classList.remove('playing');
            button.innerHTML = '<i class="fas fa-play"></i>';
            progressBar.style.width = '0%';
            currentAudio = null;
            currentButton = null;
        });
        
        audio.addEventListener('pause', () => {
            if (!audio.ended) {
                progressBar.style.width = `${(audio.currentTime / audio.duration) * 100}%`;
            }
        });
    });
}